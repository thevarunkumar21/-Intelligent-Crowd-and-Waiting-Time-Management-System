import streamlit as st
import sqlite3
from datetime import datetime
import streamlit.components.v1 as components

DB_PATH = "smartqueue.db"

st.set_page_config(page_title="SmartQueue", page_icon="⏱️", layout="wide")

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS queue_status (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                queue_name TEXT NOT NULL,
                people_count INTEGER NOT NULL DEFAULT 0,
                minutes_per_person REAL NOT NULL DEFAULT 2,
                updated_at TEXT NOT NULL
            )
        """)
        row = conn.execute("SELECT id FROM queue_status WHERE id=1").fetchone()
        if not row:
            conn.execute(
                "INSERT INTO queue_status VALUES (1, ?, ?, ?, ?)",
                ("General Service Queue", 0, 2.0, datetime.now().isoformat(timespec="minutes"))
            )

def get_status():
    with sqlite3.connect(DB_PATH) as conn:
        return conn.execute(
            "SELECT queue_name, people_count, minutes_per_person, updated_at FROM queue_status WHERE id=1"
        ).fetchone()

def update_status(queue_name, people_count, minutes_per_person):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "UPDATE queue_status SET queue_name=?, people_count=?, minutes_per_person=?, updated_at=? WHERE id=1",
            (queue_name, int(people_count), float(minutes_per_person),
             datetime.now().isoformat(timespec="minutes"))
        )

init_db()
status = get_status()
queue_name, people_count, minutes_per_person, updated_at = status
wait_minutes = round(people_count * minutes_per_person)

st.title("⏱️ SmartQueue")
st.caption("Smart Crowd and Waiting-Time Management System | QueueBreakers")

page = st.sidebar.radio("Choose page", ["Visitor View", "Staff Dashboard", "Camera Auto-Count", "About"])

if page == "Visitor View":
    st.header("Current Queue Status")
    st.subheader(queue_name)
    c1, c2 = st.columns(2)
    c1.metric("People waiting", people_count)
    c2.metric("Estimated wait", f"{wait_minutes} min")
    st.caption(f"Last updated: {updated_at.replace('T', ' ')}")
    st.info("Wait time is an estimate. Actual waiting time can vary with service speed and priority cases.")

elif page == "Staff Dashboard":
    st.header("Staff Dashboard")
    st.write("Update the public queue status. Use the camera page to estimate the number of visible people, then confirm the count here.")
    with st.form("queue_form"):
        name = st.text_input("Queue / service name", value=queue_name)
        count = st.number_input("People waiting", min_value=0, max_value=10000, value=int(people_count), step=1)
        speed = st.number_input("Average minutes per person", min_value=0.5, max_value=60.0,
                                value=float(minutes_per_person), step=0.5)
        submitted = st.form_submit_button("Save queue status")
    if submitted:
        update_status(name.strip() or "General Service Queue", int(count), float(speed))
        st.success("Queue status saved.")
        st.rerun()

elif page == "Camera Auto-Count":
    st.header("📷 Camera-based people counter")
    st.warning("Use only with permission and appropriate notice. The camera runs in your browser; avoid recording or identifying people.")
    st.write("Allow camera access, point it at the waiting area, and the AI model will estimate how many people it can detect in the current view.")
    st.caption("Detection is approximate: occlusion, distance, lighting, and camera angle can cause missed or duplicate detections. It counts visible people, not verified queue membership.")
    html = r"""
    <div style="font-family:Arial,sans-serif;color:var(--text-color,#222);">
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
        <button id="start" style="padding:10px 14px;border:0;border-radius:8px;background:#e85d75;color:white;font-weight:700">Start camera & AI</button>
        <button id="stop" style="padding:10px 14px;border:1px solid #aaa;border-radius:8px;background:transparent;color:inherit">Stop camera</button>
        <span id="status">Camera stopped</span>
      </div>
      <div style="position:relative;max-width:720px">
        <video id="video" autoplay muted playsinline style="width:100%;border-radius:12px;background:#111;display:block"></video>
        <canvas id="overlay" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"></canvas>
      </div>
      <div style="display:flex;gap:12px;align-items:center;margin-top:12px;flex-wrap:wrap">
        <div style="padding:12px 16px;border-radius:10px;background:#17233b;color:white">
          <div style="font-size:12px;opacity:.8">DETECTED PEOPLE</div>
          <div id="count" style="font-size:32px;font-weight:800">—</div>
        </div>
        <div style="font-size:13px;max-width:420px">Count updates automatically while the camera is running. The model loads from a public CDN, so internet access is required the first time.</div>
      </div>
      <div id="error" style="color:#c0392b;margin-top:8px;white-space:pre-wrap"></div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.17.0/dist/tf.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow-models/coco-ssd@2.2.3/dist/coco-ssd.min.js"></script>
    <script>
    const video=document.getElementById('video'), canvas=document.getElementById('overlay');
    const ctx=canvas.getContext('2d'), statusEl=document.getElementById('status');
    const countEl=document.getElementById('count'), errorEl=document.getElementById('error');
    let stream=null, model=null, running=false, busy=false;
    function stopCamera(){
      running=false; busy=false;
      if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}
      video.srcObject=null; ctx.clearRect(0,0,canvas.width,canvas.height);
      statusEl.textContent='Camera stopped';
    }
    document.getElementById('stop').onclick=stopCamera;
    document.getElementById('start').onclick=async()=>{
      errorEl.textContent='';
      try{
        if(!window.isSecureContext && location.hostname!=='localhost'){
          throw new Error('Camera access needs HTTPS or localhost. Deploy the app on Streamlit Community Cloud or run locally.');
        }
        statusEl.textContent='Requesting camera permission…';
        stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});
        video.srcObject=stream; await video.play();
        statusEl.textContent='Loading person-detection model…';
        if(!model){
          if(!window.cocoSsd) throw new Error('AI model scripts did not load. Check internet access and refresh the page.');
          model=await cocoSsd.load({base:'lite_mobilenet_v2'});
        }
        running=true; statusEl.textContent='Detecting people…'; detectLoop();
      }catch(e){errorEl.textContent=(e && e.message)?e.message:String(e);statusEl.textContent='Could not start';stopCamera();}
    };
    async function detectLoop(){
      if(!running || busy)return; busy=true;
      try{
        if(video.readyState>=2){
          const w=video.videoWidth,h=video.videoHeight;
          if(w&&h){
            if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
            const predictions=await model.detect(video);
            const people=predictions.filter(p=>p.class==='person' && p.score>=0.45);
            countEl.textContent=String(people.length);
            ctx.clearRect(0,0,w,h);
            ctx.lineWidth=Math.max(2,w/320); ctx.font=`${Math.max(14,w/45)}px Arial`;
            people.forEach(p=>{
              const [x,y,bw,bh]=p.bbox;
              ctx.strokeStyle='#ff6685';ctx.fillStyle='#ff6685';
              ctx.strokeRect(x,y,bw,bh);
              ctx.fillRect(x,Math.max(0,y-24),Math.max(70,ctx.measureText('person').width+12),24);
              ctx.fillStyle='#fff';ctx.fillText('person '+Math.round(p.score*100)+'%',x+5,Math.max(17,y-7));
            });
          }
        }
      }catch(e){errorEl.textContent='Detection error: '+e.message;}
      busy=false;
      if(running)setTimeout(detectLoop,350);
    }
    window.addEventListener('pagehide',stopCamera);
    </script>
    """
    components.html(html, height=590, scrolling=False)
    st.info("To publish the detected number, note the live count above, open Staff Dashboard, enter that number, and save. This starter version does not automatically write the browser count into the database.")
    st.markdown("**Privacy note:** This prototype performs detection in the browser and does not intentionally save camera footage. Get consent and follow your institution's privacy rules.")

else:
    st.header("About SmartQueue")
    st.write("SmartQueue helps visitors see queue size and estimated waiting time before they join a service queue.")
    st.markdown("""
    **Prototype features**
    - Visitor-facing queue status
    - Staff dashboard with SQLite persistence
    - Browser-based camera preview and automatic visible-person detection
    - Approximate waiting-time calculation

    **Current limitations**
    - Camera count is an estimate and can miss people in crowded or obstructed scenes.
    - Camera detections are not automatically synced to the database; staff must confirm and save the count.
    - No staff authentication yet; do not use this starter with sensitive or real operational data.
    """)
