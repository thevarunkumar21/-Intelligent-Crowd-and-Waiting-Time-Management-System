# SmartQueue — QueueBreakers

A beginner-friendly Streamlit prototype for queue visibility and waiting-time estimates.

## Features
- Visitor page shows current queue count and estimated wait.
- Staff dashboard saves queue status to a local SQLite database.
- Camera Auto-Count page uses the browser camera and TensorFlow.js COCO-SSD to estimate the number of visible people and draw boxes around detections.
- Camera inference happens in the browser; the app does not intentionally save camera footage.

## Run locally
Python 3.10+ recommended.

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit. Camera permission works on `localhost` or an HTTPS deployment. The first model load requires internet access.

## GitHub / deployment
1. Create a repository at https://github.com/new
2. Upload `app.py`, `requirements.txt`, `README.md`, and `.gitignore`.
3. Deploy on https://share.streamlit.io/ and select `app.py`.

## Important limitations
- This is a prototype, not a production queue-management system.
- AI count is approximate and can miss people due to distance, occlusion, lighting, or camera angle.
- Browser detections are **not automatically written to the SQLite queue record**. Staff must read the live count and confirm/save it in Staff Dashboard.
- No staff login or authorization is implemented.
- Obtain consent, provide notice, and follow privacy rules before using a camera in a real waiting area.
