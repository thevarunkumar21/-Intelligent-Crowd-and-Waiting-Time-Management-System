# SmartQueue Website
Responsive landing page for the SmartQueue student prototype with an interactive waiting-time calculator.

## Preview
Open `index.html` in any browser.

## Publish free using GitHub Pages
1. Create a repository at https://github.com/new
2. Upload `index.html` and `README.md` to the repository.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. After publishing, copy the live URL shown on the Pages settings screen.

Note: This is a front-end demo and is not connected to a live database or real queue. It does not use the camera.